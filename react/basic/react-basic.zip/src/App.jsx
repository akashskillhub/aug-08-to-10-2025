import LearnBasic from "./components/LearnBasic"

const App = () => {
  return <div>
    <h1>Hello React</h1>
    {/* <LearnBasic></LearnBasic> */}
    {/* XML */}
    <LearnBasic />
  </div>
}

export default App

// function formatName(firstName: string, lastName: string) {
//     let fullName: string;
//     fullName = firstName + " " + lastName;
//     fullName = fullName.toFixed(2);
//     return fullName;
// }

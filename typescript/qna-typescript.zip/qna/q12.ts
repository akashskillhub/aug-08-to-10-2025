// type UserRole = "admin" | "user";

// function checkAccess(role: UserRole) {
//     if (role === "Admin") {
//         return true;
//     }
//     return false;
// }

// let discount: number = 20;

// function applyDiscount(amount: number) {
//     let finalAmount: number;
//     finalAmount = amount - discount.toUpperCase();
//     return finalAmount;
// }

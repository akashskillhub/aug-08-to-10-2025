// function calculateSalary(basic: number, bonus: number) {
//     let salary: number = basic + bonus;

//     if (salary > "50000") {
//         return salary;
//     }
// }

// function calculateTotal(price: number, qty: number) {
//     let total: number = price * qty;
//     total = total + "10";
//     return total;
// }

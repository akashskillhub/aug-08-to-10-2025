// let message: string;

// function sendMessage(msg: string) {
//     message = msg;
// }

// sendMessage(100);
// console.log(message.toLowerCase());

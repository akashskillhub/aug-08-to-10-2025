// const isAdult = (age: number): boolean => {
//     if (age >= 18) {
//         return "Yes";
//     } else {
//         return false;
//     }
// };

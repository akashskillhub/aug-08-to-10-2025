// function calculateAverage(a: number, b: number, c: number) {
//     let avg: number;
//     avg = (a + b + c) / "3";
//     return avg;
// }

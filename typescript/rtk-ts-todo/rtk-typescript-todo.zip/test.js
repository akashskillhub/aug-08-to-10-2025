const arr = [10, 20, 30]
const x = [40, 50]
const r = [...arr, ...x]
const result = arr.concat(x)
console.log(result)
console.log(r)

export type TODO_TYPE = {
    id?: number,
    task: string,
    desc: string,
    priority: string,
    complete: boolean,
}
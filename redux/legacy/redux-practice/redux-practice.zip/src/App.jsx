import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Counter from './pages/Counter'
import Todo from './pages/Todo'
import Navbar from './components/Navbar'

const App = () => {
  return <>
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path='/' element={<Counter />} />
        <Route path='/todo' element={<Todo />} />
        <Route path='*' element={<h1>Page Not Found</h1>} />
      </Routes>
    </BrowserRouter>
  </>
}

export default App
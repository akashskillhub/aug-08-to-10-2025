export const INC = "INC"
export const DEC = "DEC"
export const RESET = "RESET"
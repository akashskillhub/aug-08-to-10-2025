const totalBtn = 4
const x = []
const y = Array.from({ length: totalBtn })
console.log(y)
const p = y.map(item => 'hello')
console.log(p)


